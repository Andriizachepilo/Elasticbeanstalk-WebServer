module.exports = {
  mongoURI: 'mongodb://Andrey79342:Andrey79342@tf-20240429203947509300000005.cpigoksykqdt.eu-west-2.docdb.amazonaws.com:27017/?tls=true&tlsCAFile=global-bundle.pem&retryWrites=false'
}
